<!-- Code by Chung Ming Cheng -->
<!doctype html>
<html lang="en">
  <head>
    <title>Green Fee</title>
    <meta charset="utf-8">
    
  </head>
  <body>
  <?php
	$db = new PDO("mysql:dbname=dbv3", "root", "");
	$rows = $db->query("SELECT * FROM question");
	?>
	<div id="qstns">
		<form action="comments.html">
	
	<?php
	foreach ($rows as $row) {
  ?>
	
			<div id="q<?= $row["ID"] ?>"> 
			<p>Question <?= $row["ID"] ?></p>
			<?= $row["Text"]  ?>
			<br>
			<input type="radio" name="res1" value="exc1">
			<input type="radio" name="res1" value="vgood1">
			<input type="radio" name="res1" value="good1">
			<input type="radio" name="res1" value="fair1">
			<input type="radio" name="res1" value="min1">
			<input type="radio" name="res1" value="na1"><br>
			<label>Comments: <input type="text" name="com<?= $row["ID"] ?>"></label><br>
			</div>
  <?php
}
  ?>
  <input type="submit" value="Continue">
		</form>
  </body>
</html>