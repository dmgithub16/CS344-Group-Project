<!-- Code by Chung Ming Cheng -->
<!doctype html>
<html lang="en">
  <head>
    <title>Green Fee</title>
    <meta charset="utf-8">
    
  </head>
  <body>
  <?php
	$UID = $_POST["uid"];
	$PID = $_POST["projnum"];
	$Name = $_POST["name"];
	$Status = $_POST["affl"];
  
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "dbv3";
  
	$db = new PDO("mysql:dbname=$dbname;host=$servername", "$username");
	$db-> query("UPDATE user SET Name = '$Name' WHERE ID = '$UID';");
	$db-> query("UPDATE review SET Name = '$Name' WHERE User_ID = '$UID';");
	$db-> query("UPDATE review SET Project_ID = '$PID' WHERE User_ID = '$UID';");
	$db-> query("UPDATE user SET Status = '$Status' WHERE ID = '$UID';");
	
	?>
	<div id="qstns">
		<form action="comments.php" method="POST">
		User ID :
			<select name="uid">
				<option selected="selected"><?=$UID?></option>
			</select><br>
	<?php		
		
	$rows = $db->query("SELECT * FROM question");
	foreach ($rows as $row) {
		$db-> query("INSERT INTO answer (User_ID,Question_ID,Project_ID)VALUES ('$UID','$row[ID]','$PID')");
  ?>
	
			<div id="q<?= $row["ID"] ?>"> 
			<p>Question <?= $row["ID"] ?></p>
			<?= $row["Text"]  ?>
			<br>
			<input type="radio" name='res<?= $row["ID"] ?>' value="exc1">
			<input type="radio" name='res<?= $row["ID"] ?>' value="vgood1">
			<input type="radio" name='res<?= $row["ID"] ?>' value="good1">
			<input type="radio" name='res<?= $row["ID"] ?>' value="fair1">
			<input type="radio" name='res<?= $row["ID"] ?>' value="min1">
			<input type="radio" name='res<?= $row["ID"] ?>' value="na1"><br>
			<label>Comments: <input type="text" name="com<?=$row["ID"] ?>"></label><br>
			</div>
  <?php
}
  ?>
  <input type="submit" value="Continue">
		</form>
  </body>
</html>