<!doctype html>
<html lang="en">
  <head>
    <title>Green Fee</title>
    <meta charset="utf-8">
    
  </head>
  <body>
  <?php
  $UID = $_POST["username"];
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "dbv3";
  
  $db = new PDO("mysql:dbname=$dbname;host=$servername", "$username");
  $db-> query("INSERT INTO user (ID)VALUES ($UID)");
  $db-> query("INSERT INTO admin (User_ID)VALUES ($UID)");
  $db-> query("INSERT INTO review (User_ID)VALUES ($UID)");
  $db-> query("INSERT INTO project (User_ID)VALUES ($UID)");
 
?>
	<div id="info">
		<form action="questions.php" method="POST">
			
			User ID :
			<select name="uid">
				<option selected="selected"><?=$UID?></option>
			</select>
			<br>
			Project ID :
			<select name="projnum">
				<option value="p1">Project 1</option>
				<option value="p2">Project 2</option>
				<option value="p3">Project 3</option>
			</select><br>
			<label>Name: <input type="text" name="name"></label><br>
			Affiliation:
			<label>Student: <input type="radio" name="affl" value="stud"></label>
			<label>Non-Student<input type="radio" name="affl" value="nonstud"></label><br>
			<input type="submit" value="Continue">
		</form>
	</div>
  </body>
</html>