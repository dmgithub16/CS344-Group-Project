<!doctype html>
<html lang="en">
  <head>
    <title>Green Fee</title>
    <meta charset="utf-8">
    
  </head>
  <body>
  <?php	
	$UID = $_POST["uid"];
	$ANS = $_POST["uid"];
	
	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "dbv3";
  
	$db = new PDO("mysql:dbname=$dbname;host=$servername", "$username");
	$rows = $db->query("SELECT * FROM question");
	
	foreach ($rows as $row) {
		$ANS= $_POST["res$row[ID]"];
		$Comments= $_POST["com$row[ID]"];
		$db-> query("UPDATE answer SET Answer = '$ANS' WHERE Question_ID = '$row[ID]' AND USer_ID= '$UID';");
		$db-> query("UPDATE answer SET Comment = '$Comments' WHERE Question_ID = '$row[ID]' AND USer_ID= '$UID';");
	}
	?>
	<div id="cmnts">
	
			
		General Comments:<br>
		
		<form id="txtarea" action="submit.php" method="POST">
			User ID :
			<select name="uid">
				<option selected="selected"><?=$UID?></option>
			</select>
			<br>
			<textarea rows="7" cols="50" name="comment" form="txtarea"></textarea>
			<input type="submit" value="Submit">
		</form>
	</div>
  </body>
</html>