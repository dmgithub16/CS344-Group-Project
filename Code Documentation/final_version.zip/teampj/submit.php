<!doctype html>
<html lang="en">
  <head>
    <title>Green Fee</title>
    <meta charset="utf-8">
    
  </head>
  <body>
  <?php
	$G_Com = $_POST["comment"];
	$UID = $_POST["uid"];
	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "dbv3";
  
	$db = new PDO("mysql:dbname=$dbname;host=$servername", "$username");
	$db-> query("UPDATE review SET Comments = '$G_Com' WHERE User_ID ='$UID'");
	
	?>
	Thank you
	 </body>
</html>